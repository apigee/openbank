var express = require('express');
var app = express();

var accounts = require("./accounts.js");

/*
 * GET /acr:token/info
 * GET Account Information
 */
app.get('/acr:token', accounts.getAccountInfo);
app.get('/acr:token/info', accounts.getAccountInfo);

/*
 * GET /acr:token/balance
 * GET Account balance details
 */
app.get('/acr:token/balance', accounts.getAccountBalance);

/*
 *  GET /acr:token/transactions
 *  GET Transaction of an Account
 */
app.get('/acr:token/transactions', accounts.getAccountTransaction);
app.get('/acr:token/transactions/:transactionId', accounts.getAccountTransaction);

app.listen(3000, function () {
  console.log('App listening on port 3000!');
});
