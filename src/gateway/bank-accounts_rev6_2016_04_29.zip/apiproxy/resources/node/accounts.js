var request = require('request');
var apigee = require('apigee-access');
var config = require( "./config.js");

var apiendPoint = config.usegridHost+'/'+config.usergridOrg+'/'+config.usergridApp;

function getAccountDetails (req, callback) {
    var CustomerNumber,AccountNumber;
      if(apigee.getMode() == 'apigee') {
      	CustomerNumber = apigee.getVariable(req,'accesstoken.customer_number');
      	AccountNumber = apigee.getVariable(req,'accesstoken.account_number');
      }	else if(apigee.getMode() == 'standalone') {
      	CustomerNumber = "84487942";
      	AccountNumber = "74379891646";
      }
      
      var options = {
    	  url: apiendPoint+"/banks/"+config.defaultBank+"/customers;ql=where name='"+CustomerNumber+"'/accounts;ql=where name='"+AccountNumber+"'",
    	  json: true
      };
      
    request(options, function (error, response, body) {
	  if (!error && response.statusCode == 200) {
	  	    var accountDetails = body.entities[0];
	    
	  	    accountDetails.id = accountDetails.name;
	  	    accountDetails.created_at = accountDetails.created;
    	  	accountDetails.updated_at = accountDetails.modified;
	  	    
	  	    delete accountDetails.name;
	  	    delete accountDetails.created;
	  	    delete accountDetails.modified;
	  	    
    	  	delete accountDetails.uuid;
    	  	delete accountDetails.type;
    	  	delete accountDetails.metadata;
	  	    
	  	    callback(accountDetails);
	  } else {
	      callback(null);
	  }
    });
}

exports.getAccountInfo = function (req,res) {
 getAccountDetails(req, function (details) {
        delete details.balanceAmount;
      	delete details.clearingAmount;
      	
      	delete details.balance;
      	delete details.balance_available;
      	delete details.cash_flow_per_year;
      	delete details.preauth_amount;
    res.send(details);     
 });
}

exports.getAccountBalance = function (req, res) {
    getAccountDetails(req, function (details) {
        var balance = {};
            if (details.hasOwnProperty('balanceAmount')) {
                balance.accountLabel = details.accountLabel;
                balance.balanceAmount = details.balanceAmount;
    	  		balance.clearingAmount = details.clearingAmount;
    	  		balance.currency = details.currency;
            } else {
                balance.balance = details.balance;
                balance.balance_available = details.balance_available;
                balance.cash_flow_per_year = details.cash_flow_per_year;
                balance.currency = details.currency;
                balance.preauth_amount = details.preauth_amount;
            }
    res.send(balance);     
 });
}

exports.getAccountTransaction = function (req,res,next) {
  var CustomerNumber,AccountNumber;
  if(apigee.getMode() == 'apigee') {
  	CustomerNumber = apigee.getVariable(req,'accesstoken.customer_number');
  	AccountNumber = apigee.getVariable(req,'accesstoken.account_number');
  }	else if(apigee.getMode() == 'standalone') {
  	CustomerNumber = "84487942";
  	AccountNumber = "74379891646";
  }
  	
  var options = {
	  url: apiendPoint+"/banks/"+config.defaultBank+"/customers;ql=where name='"+CustomerNumber+"'/accounts;ql=where name='"+AccountNumber+"'/transactions",
	  qs: {
	      limit: 1000
	  },
	  json: true
  };
  
  if (req.params.transactionId) {
      options.url += '/' + req.params.transactionId;
  }
 
  request(options, function (error, response, body) {
	  if (!error && response.statusCode == 200) {
	  	transactions = [];
	  	for (var i = body.entities.length - 1; i >= 0; i--) {
	  	    if (!body.entities[i].hasOwnProperty('account_id')) {
	  	        transactions.push( {
    	  		  "transactionId": body.entities[i].uuid,
    		      "amount": body.entities[i].amount,
    		      "currency": body.entities[i].currency,
    		      "description": body.entities[i].description,		      
    		      "transactionCategory": body.entities[i].transactionCategory,
    		      "transactionType": body.entities[i].transactionType,
    		      "payeeAccount": body.entities[i].payeeAccount,
    		      "payeeIBAN": body.entities[i].payeeIBAN,
    		      "payeeSortCode": body.entities[i].payeeSortCode,
		        });
	  	    } else {
	  	        var transaction = body.entities[i];
	  	        
	  	        transaction.id = transaction.uuid;
    	  	    transaction.created_at = transaction.created;
        	  	transaction.updated_at = transaction.modified;

    	  	    delete transaction.created;
	  	        delete transaction.modified;
	  	        
                delete transaction.uuid;
    	  	    delete transaction.type;
    	  	    delete transaction.metadata;	  	        
	  	        
	  	        transactions.push(transaction);
	  	    }
	  		
	  	};
	    res.send(transactions);
	  }	  
  });
}