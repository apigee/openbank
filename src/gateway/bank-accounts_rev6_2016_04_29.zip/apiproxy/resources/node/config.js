module.exports = {
	"usegridHost": "https://api.usergrid.com",
	"usergridOrg": "psubrahmanyam",
	"usergridApp": "apisbank",	
	"defaultBank": "ebank",	
};