module.exports = {
	"host": "https://api.usergrid.com",
	"org": "psubrahmanyam",
	"app": "apisbank",
	"bank": "ebank"
};